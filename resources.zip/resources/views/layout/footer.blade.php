<footer>
    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center">
                    <p class="fh5co-social-icons">
                        <a href="#"><i class="icon-twitter2"></i></a>
                        <a href="#"><i class="icon-facebook2"></i></a>
                        <a href="#"><i class="icon-instagram"></i></a>
                        <a href="#"><i class="icon-dribbble2"></i></a>
                        <a href="#"><i class="icon-youtube"></i></a>
                    </p>
                    <p>RUA SÃO JOSÉ, Nº 40 <br/>
                        2º ANDAR - SALA 24 <br/>
                        CENTRO - RJ <br/>
                        20010-020
                    </p>
                    <p>Copyright @2016 <a href="/">Uno Traduções</a>. All Rights Reserved.</p>
                    <p id="develop-by">Desenvolvido por <a href="https://br.linkedin.com/in/jonathan-iqueda-baa098a0"
                                                           target="_blank">Jonathan Iqueda</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
