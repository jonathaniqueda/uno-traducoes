<!-- end:header-top -->
<span id="missao"></span>
<div id="fh5co-services-section" class="fh5co-section-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
                @lang('general.mis_sec1')
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                <img src="{{asset('images/missao-uno-traducao.jpg')}}" class="img-responsive"
                     style="margin: 0 auto;">
                <p style="margin-top: 50px">
                    @lang('general.mis_sec2')
                </p>
                <p style="margin-top: 50px">
                    Ser reconhecida como a referência no mercado de traduções e interpretações.
                </p>
            </div>
        </div>
    </div>
</div>
