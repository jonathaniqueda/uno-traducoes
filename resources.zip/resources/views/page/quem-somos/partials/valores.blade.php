@include('page.call-to-action')
<!-- end:header-top -->
<span id="valores"></span>
<div id="fh5co-services-section" class="fh5co-section-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
                @lang('general.val_sec1')
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                @lang ('general.val_sec2')
                <ul>
                    @lang('general.val_sec3')
                </ul>
            </div>
        </div>
    </div>
</div>
