<!-- end:header-top -->
<span id="visao"></span>
<div id="fh5co-services-section">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
                @lang('general.visao_sec1')
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                @lang('general.visao_sec2')
                <p>
                    @lang('general.visao_sec3')
                </p>
            </div>
        </div>
    </div>
</div>
