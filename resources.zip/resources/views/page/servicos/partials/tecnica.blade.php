@include('page.call-to-action')
<span id="tecnica"></span>
<div id="fh5co-services-section">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
                @lang('general.tec_sec1')
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                <img src="{{asset('images/traducao-tecnica.jpg')}}" class="img-responsive"
                     style="margin: 0 auto;">
                <p style="margin-top: 50px;">
                        @lang('general.tec_sec2')
                </p>
            </div>
        </div>
    </div>
</div>
