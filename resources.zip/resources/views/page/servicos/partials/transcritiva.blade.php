<span id="transcritiva"></span>
<div id="fh5co-services-section">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
                @lang('general.trans_sec1')
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                <p>
                    @lang('general.trans_sec2')
                </p>
            </div>
        </div>
    </div>
</div>
