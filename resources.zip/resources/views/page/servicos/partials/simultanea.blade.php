<span id="simultanea"></span>
<div id="fh5co-services-section">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
                @lang('general.sim_sec1')
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                <img src="{{asset('images/interpretacao-simultanea.jpg')}}" class="img-responsive"
                     style="margin: 0 auto;">

                <p style="margin-top: 50px;">
                    @lang('general.sim_sec2')
                </p>

                <p>
                    @lang('general.sim_sec3')
                </p>

                <ul>
                    @lang('general.sim_sec4')
                </ul>

            </div>
        </div>
    </div>
</div>
