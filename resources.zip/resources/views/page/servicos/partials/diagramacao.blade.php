<span id="diagramacao"></span>
<div id="fh5co-services-section" class="fh5co-section-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
                @lang('general.dia_sec1')
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                <p>
                    @lang('general.dia_sec2')
                </p>
            </div>
        </div>
    </div>
</div>
