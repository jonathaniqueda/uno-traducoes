<div class="call-to-action-banner">
    <div class="divulgacao-contato">
        <h3 class="banner">
            @lang('general.call_sec1')
        </h3>
        <a class="btn btn-primary" href="{{route('index', ['entre-em-contato'])}}">
            @lang('general.call_sec2')
        </a>
    </div>
</div>